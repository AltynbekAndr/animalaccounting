package kz.putinbyte.iszhfermer.presentation.scanner

import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_login.*
import moxy.viewstate.strategy.alias.Skip
import kz.putinbyte.iszhfermer.presentation.base.BaseView

interface ScannerView : BaseView {

    @Skip
    fun back()

    @Skip
    fun showErrorMessage(message: String)
}