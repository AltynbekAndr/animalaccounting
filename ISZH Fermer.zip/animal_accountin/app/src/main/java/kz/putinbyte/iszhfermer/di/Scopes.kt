package kz.putinbyte.iszhfermer.di

object Scopes {

    const val APP_SCOPE = "app scope"
    const val DATA_SCOPE = "data scope"
    const val SERVER_SCOPE = "server scope"
}