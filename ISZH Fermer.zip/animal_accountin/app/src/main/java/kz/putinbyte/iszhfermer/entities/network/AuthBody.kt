package kz.putinbyte.iszhfermer.entities.network

class AuthBody(
    val login: String,
    val password: String
)
