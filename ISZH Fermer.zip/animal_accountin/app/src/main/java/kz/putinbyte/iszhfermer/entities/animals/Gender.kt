package kz.putinbyte.iszhfermer.entities.animals

data class Gender(
    var id: Int?,
    val code: String?,
    val nameRu: String?,
    val nameKz: String?
)
