package kz.putinbyte.iszhfermer.model.data.enums

enum class ListRegion {
    ADD_ANIMAL,
    OWNER_BUTTON,
    NEXT_LEVEL
}

enum class SearchListRegion {
    CHOOSE,
    NEXT
}
enum class FieldType{
    SPINNER,
    INPUT,
    DATE,
    FILE
}