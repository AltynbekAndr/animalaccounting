package kz.putinbyte.iszhfermer.entities.iszh

class ScheduleItem(
    val date: String?
)