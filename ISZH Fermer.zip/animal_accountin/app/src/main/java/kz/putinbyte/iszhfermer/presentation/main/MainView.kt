package kz.putinbyte.iszhfermer.presentation.main

import kz.putinbyte.iszhfermer.entities.animals.AnimalList
import kz.putinbyte.iszhfermer.entities.requests.UserInfoList
import moxy.viewstate.strategy.alias.AddToEndSingle
import kz.putinbyte.iszhfermer.presentation.base.BaseView

interface MainView : BaseView {

    @AddToEndSingle
    fun setTitle(title: String)

    @AddToEndSingle
    fun showConfirmExitDialog()

    @AddToEndSingle
    fun showAlert(list: List<AnimalList.Animals>?)

    @AddToEndSingle
    fun showUserAlert(userInfo: UserInfoList.UserInfo?)
}