package kz.putinbyte.iszhfermer.entities.requests

data class OrgStructure(
    val katoId: Int,
    val nameKz: String,
    val nameRu: String
)