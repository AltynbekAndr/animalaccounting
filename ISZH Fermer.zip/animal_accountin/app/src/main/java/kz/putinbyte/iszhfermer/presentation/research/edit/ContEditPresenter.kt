package kz.putinbyte.iszhfermer.presentation.research.edit

import kotlinx.coroutines.launch
import kz.putinbyte.iszhfermer.entities.BaseFormat
import kz.putinbyte.iszhfermer.model.interactors.RegAnimalInteractor
import kz.putinbyte.iszhfermer.model.interactors.ReferencesInteractor
import kz.putinbyte.iszhfermer.presentation.base.BasePresenter
import ru.terrakok.cicerone.Router
import timber.log.Timber
import javax.inject.Inject

class ContEditPresenter @Inject constructor(
    private val router: Router,
    private val referencesInteractor: ReferencesInteractor,
    private val iszhInteractor: RegAnimalInteractor
) : BasePresenter<ContEditView>() {

    lateinit var contId: String

    override fun onFirstViewAttach() {
        super.onFirstViewAttach()

        loadContTypes()
        loadGarbageTypes()
    }

    override fun attachView(view: ContEditView?) {
        super.attachView(view)

    }

    fun setName(s: String) {

    }

    fun setSeparateType(type: String, isChecked: Boolean, number: String) {
        Timber.d("__v SET SEPARATE TYPE T: $type CH: $isChecked N: $number")
        try {

        } catch (e: Exception) {
            e.printStackTrace()
            Timber.e(e)
        }
    }


    fun onPermissionDenied(s: String) {
        viewState.showMessage(s)
    }

    fun onRemoveClicked() {
        val newIszh = iszhInteractor.getCurrentIszh()
        iszhInteractor.setCurrentIszh(newIszh)
        router.exit()
    }

    fun onTypeChanged(items: List<BaseFormat>, position: Int) {
        viewState.switchTypesVisibility(
            items[position]
                .nameRu.equals("владелец для раздельного сбора")
        )
        viewState.switchGarbageVisibility(
            items[position]
                .nameRu.equals("владелец")
        )
    }

    private fun loadContTypes() {
        launch {
            try {
            } catch (e: Exception) {
                e.printStackTrace()
                Timber.e(e)
            }
        }
    }

    private fun loadTankTypes() {
        launch {
            try {
               // val result = referencesInteractor.getTankTypes(false)
               // viewState.showTankTypes(result)
            } catch (e: Exception) {
                e.printStackTrace()
                Timber.e(e)
            }
        }
    }

    private fun loadGarbageTypes() {
        launch {
            try {
                //val result = referencesInteractor.getGarbageTypes(false)
                //viewState.showGarbageTypes(result)
            } catch (e: Exception) {
                e.printStackTrace()
                Timber.e(e)
            }
        }
    }

    fun onSaveClicked() {
        val newIszh = iszhInteractor.getCurrentIszh()
        iszhInteractor.setCurrentIszh(newIszh)
        router.exit()
    }

    fun onGarbageChanged(items: List<BaseFormat>, position: Int) {
    }
}