package  kz.putinbyte.iszhfermer.model.data.db.converters


class EnumConverters2 {

}