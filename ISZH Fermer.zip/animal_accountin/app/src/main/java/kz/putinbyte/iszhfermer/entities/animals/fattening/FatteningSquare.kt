package kz.putinbyte.iszhfermer.entities.animals.fattening

data class FatteningSquare(
    val count: Int,
    val lists: List<Lists>
)