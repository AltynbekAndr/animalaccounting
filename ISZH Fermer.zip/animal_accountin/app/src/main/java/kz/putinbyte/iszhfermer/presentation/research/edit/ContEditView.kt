package kz.putinbyte.iszhfermer.presentation.research.edit

import kz.putinbyte.iszhfermer.entities.BaseFormat
import moxy.viewstate.strategy.alias.AddToEndSingle
import kz.putinbyte.iszhfermer.entities.iszh.Media
import kz.putinbyte.iszhfermer.presentation.base.BaseView

interface ContEditView : BaseView {

    @AddToEndSingle
    fun showContTypes(items: List<BaseFormat>)

    @AddToEndSingle
    fun showContStates(items: List<BaseFormat>)

    @AddToEndSingle
    fun showTankTypes(items: List<BaseFormat>)

    @AddToEndSingle
    fun showGarbageTypes(items: List<BaseFormat>)

    @AddToEndSingle
    fun setList(items: List<Media>)

    @AddToEndSingle
    fun switchTypesVisibility(isVisible: Boolean)

    @AddToEndSingle
    fun switchGarbageVisibility(visible: Boolean)
}