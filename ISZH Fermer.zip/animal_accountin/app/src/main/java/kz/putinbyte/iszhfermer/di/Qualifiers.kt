package kz.putinbyte.iszhfermer.di

import javax.inject.Qualifier

@Qualifier
annotation class DadataApiPath

@Qualifier
annotation class IszhApiPath

@Qualifier
annotation class AuthApiPath

@Qualifier
annotation class RegApiPath

@Qualifier
annotation class ApiPath

