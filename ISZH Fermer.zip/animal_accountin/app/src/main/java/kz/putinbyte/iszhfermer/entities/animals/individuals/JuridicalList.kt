package kz.putinbyte.iszhfermer.entities.animals.individuals

data class JuridicalList(
    val count: Int,
    val list: List<Juridical>
)