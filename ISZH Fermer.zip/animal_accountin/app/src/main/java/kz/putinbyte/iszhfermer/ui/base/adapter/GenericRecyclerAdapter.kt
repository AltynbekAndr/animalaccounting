package kz.putinbyte.iszhfermer.ui.base.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kz.putinbyte.iszhfermer.entities.BaseFormat

abstract class GenericRecyclerAdapter<T>(var items: ArrayList<T>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    abstract fun bind(item: T, holder: ViewHolder)

    fun update(items: ArrayList<T>) {
        this.items = items
        notifyItemRangeChanged(items.size, items.size)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.count()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(viewType, parent, false)
        return ViewHolder(view)
    }

    fun getListPosition(position: Int): T {
        return items[position]
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        bind(items[position], holder as ViewHolder)
    }

    fun deleteUpdater(position: Int, item: T){
        items.removeAt(position)
        items.addAll(position, listOf(item));
    }

    fun deleteItem(item: T, holder: ViewHolder){
        items.remove(item)
        notifyItemRemoved(holder.adapterPosition)
    }
}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view)