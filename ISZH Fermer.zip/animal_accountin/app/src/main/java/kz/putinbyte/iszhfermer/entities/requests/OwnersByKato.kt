package kz.putinbyte.iszhfermer.entities.requests

data class OwnersByKato(
    val culture: Int = 2,
    val katoId: Int
)
