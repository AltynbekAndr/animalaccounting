package kz.putinbyte.iszhfermer.ui.research.create.rv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.v12ten.mvp_rentcycle.ui.trips.rv.ContCreateHolder
import iszhfermer.R
import kotlinx.android.synthetic.main.item_iszh.view.*
import kz.putinbyte.iszhfermer.ui.animal.list.rv.TestModel

open class ContCreateAdapter(
    private val onItemClick: ((items: ArrayList<TestModel>?, position: Int) -> Unit)? = null
) : RecyclerView.Adapter<ContCreateHolder>() {

    var items: ArrayList<TestModel>? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContCreateHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_iszh, parent, false)

        return object : ContCreateHolder(v) {
            override fun onClick(v: View?) {}
        }
    }

    override fun getItemCount(): Int {
        return if (items != null) items!!.size else 0
    }

    override fun onBindViewHolder(holder: ContCreateHolder, position: Int) {

        (holder).itemView.iszhInjText.text = items!![position].textInj ?: ""
        (holder).itemView.iszhBreedText.text = items!![position].breed ?: ""
        (holder).itemView.iszhGenderText.text = items!![position].gender ?: ""
        (holder).itemView.iszhBirthdayText.text = items!![position].birthday ?: ""
    }
}