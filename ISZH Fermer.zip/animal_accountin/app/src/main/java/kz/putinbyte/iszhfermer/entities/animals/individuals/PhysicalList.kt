package kz.putinbyte.iszhfermer.entities.animals.individuals

data class PhysicalList(
    val count: Int,
    val list: List<Physical>
)