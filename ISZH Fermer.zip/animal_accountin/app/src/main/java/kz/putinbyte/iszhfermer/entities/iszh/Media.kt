package kz.putinbyte.iszhfermer.entities.iszh

class Media(
    var id: String,
    val type: String?,
    var wasteStorageTankId: String?
)