package kz.putinbyte.iszhfermer.ui.research.edit.rv

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import iszhfermer.R
import kz.putinbyte.iszhfermer.entities.iszh.Media

open class ContEditAdapter(
    private val context: Context,
    private val onItemClick: ((items: List<Media>?, position: Int) -> Unit)? = null
) : RecyclerView.Adapter<ContEditHolder>() {

    var items: List<Media>? = null
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContEditHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_camera, parent, false)
        return object : ContEditHolder(v) {}
    }

    override fun getItemCount(): Int {
        return if (items != null) items!!.size else 0
    }

    override fun onBindViewHolder(holder: ContEditHolder, position: Int) {

    }
}