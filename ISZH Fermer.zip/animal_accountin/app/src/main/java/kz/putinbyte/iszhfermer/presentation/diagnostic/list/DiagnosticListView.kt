package kz.putinbyte.iszhfermer.presentation.diagnostic.list

import moxy.viewstate.strategy.alias.AddToEndSingle
import kz.putinbyte.iszhfermer.entities.iszh.Reference
import kz.putinbyte.iszhfermer.presentation.base.BaseView

interface DiagnosticListView : BaseView {

    @AddToEndSingle
    fun showContTypes(items: List<Reference>)
}