package kz.putinbyte.iszhfermer.ui.deposit.list.rv

data class DepositTest(
    val name:String?,
    val zalog:String?,
    val handle:String?,
    val regisNum:String?,
    val numDoc:String?,
    val dateStart:String?,
    val dateEnd:String?,
    val summ:String?,
    val commen:String?,
    val doc:String?,
)