package kz.putinbyte.iszhfermer.entities.animals.owners

data class OwnersList(
    val count: Int,
    val list: List<Owners>?
)