package kz.putinbyte.iszhfermer.entities.iszh

class Filter(
    val name: String,
    var isChecked: Boolean
)
