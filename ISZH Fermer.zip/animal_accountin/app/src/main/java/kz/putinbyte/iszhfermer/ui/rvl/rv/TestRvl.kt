package kz.putinbyte.iszhfermer.ui.rvl.rv

data class TestRvl(
    val inj:String,
    val owner:String?,
    val inn:String?,
    val birthDate:String?,
    val gender:String?,
    val animalKind:String?,
    val test:String?
)
