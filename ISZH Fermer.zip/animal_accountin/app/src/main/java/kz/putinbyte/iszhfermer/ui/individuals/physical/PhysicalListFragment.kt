package kz.putinbyte.iszhfermer.ui.individuals.physical

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.AdapterView
import android.widget.DatePicker
import com.google.android.material.snackbar.Snackbar
import iszhfermer.R
import kotlinx.android.synthetic.main.fragment_physical.*
import kotlinx.android.synthetic.main.item_date.view.*
import kotlinx.android.synthetic.main.item_spinner.view.*
import moxy.presenter.InjectPresenter
import moxy.presenter.ProvidePresenter
import kz.putinbyte.iszhfermer.di.Scopes
import kz.putinbyte.iszhfermer.entities.BaseFormat
import kz.putinbyte.iszhfermer.entities.FieldData
import kz.putinbyte.iszhfermer.entities.network.region.Region
import kz.putinbyte.iszhfermer.extensions.afterTextChanged
import kz.putinbyte.iszhfermer.extensions.visible
import kz.putinbyte.iszhfermer.model.data.enums.FieldType
import kz.putinbyte.iszhfermer.presentation.individuals.physical.PhysicalPresenter
import kz.putinbyte.iszhfermer.presentation.individuals.physical.PhysicalView
import kz.putinbyte.iszhfermer.presentation.main.MainView
import kz.putinbyte.iszhfermer.ui.base.BaseFragment
import kz.putinbyte.iszhfermer.ui.search.dialogRegions.RegionsBottomSheetFragment
import kz.putinbyte.iszhfermer.utils.LogUtils
import toothpick.Toothpick
import java.text.SimpleDateFormat
import java.util.*

class PhysicalListFragment : BaseFragment(), PhysicalView {

    override val layoutResId = R.layout.fragment_physical

    companion object {

        fun newInstance() = PhysicalListFragment()
    }

    @InjectPresenter
    lateinit var presenter: PhysicalPresenter

    @ProvidePresenter
    fun providePresenter(): PhysicalPresenter {
        return Toothpick.openScope(Scopes.DATA_SCOPE)
            .getInstance(PhysicalPresenter::class.java)
    }

    lateinit var fields: List<FieldData>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as MainView).setTitle(getString(R.string.addindivid))
        initListeners()

        fields = listOf(
            FieldData("iin", addOwnerINN, FieldType.INPUT),
            FieldData("lastName", addOwnerLastName, FieldType.INPUT),
            FieldData("firstName", addOwnerFirstName, FieldType.INPUT),
            FieldData("middleName", addOwnerMiddleName, FieldType.INPUT),
            FieldData("birthDate", addOwnerBirthDateEdit, FieldType.DATE),
            FieldData("kato", addOwnerKatoId, FieldType.INPUT),
            FieldData("email", addOwnerEmail, FieldType.INPUT),
            FieldData("documentNum", addOwnerDocumentNumber, FieldType.INPUT),
            FieldData("Country", addOwnerCitizenshipId, FieldType.SPINNER),
            FieldData("date", addOwnerDocumentDateIssue, FieldType.DATE),
            FieldData("issuedBy", addOwnerDocumentIssueBy, FieldType.INPUT)
        )
    }

    private fun initListeners() {

        addOwnerINN.afterTextChanged { presenter.physical.iin = it }
        addOwnerLastName.afterTextChanged { presenter.physical.lastName = it }
        addOwnerFirstName.afterTextChanged { presenter.physical.firstName = it }
        addOwnerMiddleName.afterTextChanged { presenter.physical.middleName = it }
        addOwnerEmail.afterTextChanged { presenter.physical.email = it }
        addOwnerTel.afterTextChanged { presenter.physical.tel = it }
        addOwnerMobilePhone.afterTextChanged { presenter.physical.mobilePhone = it }
        addOwnerDocumentNumber.afterTextChanged { presenter.physical.documentNumber = it }
        addOwnerDocumentIssueBy.afterTextChanged { presenter.physical.doumentIssueBy = it }
        addOwnerPostIndex.afterTextChanged { presenter.physical.postIndex = it }
        addOwnerStreet.afterTextChanged { presenter.physical.street = it }
        addOwnerHouse.afterTextChanged { presenter.physical.house = it }
        addOwnerFlat.afterTextChanged { presenter.physical.flat = it }

        physicalCreatesButton.setOnClickListener {
            presenter.onSaveClicked()
        }

        addOwnerBirthDateEdit.itemDateButton.setOnClickListener {
            showDatePickerDialog(true)
        }

        addOwnerDocumentDateIssue.itemDateButton.setOnClickListener {
            showDatePickerDialog(false)
        }

        addOwnerKatoId.setOnClickListener {
            it.isEnabled = false
            Handler(Looper.getMainLooper()).postDelayed({
                showAlertRegions()
            }, 500)
        }

        addOwnerCitizenshipId.itemSpinnerSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    presenter.physical.citizenshipId = addOwnerCitizenshipId.items[position].id!!
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        asterisksFields()
    }

    override fun showLoader(show: Boolean) {
        if (show)
            alert.show()
        else
            alert.hide()
    }

    override fun showCountryOrigin(result: List<BaseFormat>) {
        addOwnerCitizenshipId.visible(!result.isNullOrEmpty())
        val newList = arrayListOf<BaseFormat>()
        newList.add(BaseFormat(0, null, "Выберите страну", null))
        newList.addAll(result)
        addOwnerCitizenshipId.items = newList
    }

    override fun visibleReset(visible: Boolean) {
        addOwnerCitizenshipId.visible(visible)
    }

    override fun resetError() {
        presenter.validateError = false
        baseResetError(fields)
    }

    override fun showValidateError(error: Boolean, fieldKey: String) {
        if (error) {
            presenter.validateError = true
            baseValidateError(fields,fieldKey)
        }
    }

    override fun showMessage(msg: String) {
        try {
            Snackbar.make(
                physicalFragment,
                msg,
                Snackbar.LENGTH_LONG
            )
                .show()
        } catch (e: Exception) {
            LogUtils.error(javaClass.simpleName, e.message)
        }
    }

    private fun showAlertRegions() {
        val bottomSheetDialogFragment =
            RegionsBottomSheetFragment(object : RegionsBottomSheetFragment.Listener {
                override fun setOnClick(items: Region.AnimalAmountByKato) {
                    addOwnerKatoId.text = items.name
                    presenter.physical.katoId = (items.id)
                }
            })
        bottomSheetDialogFragment.show(
            requireActivity().supportFragmentManager,
            bottomSheetDialogFragment.tag
        )
        addOwnerKatoId.isEnabled = true
    }

    fun showDatePickerDialog(isStart: Boolean) {
        val calendar = Calendar.getInstance()
        val mDay = calendar.get(Calendar.DAY_OF_MONTH)
        val mMonth = calendar.get(Calendar.MONTH)
        val mYear = calendar.get(Calendar.YEAR)
        val backFormat = SimpleDateFormat(getString(R.string.app_back_date))
        val frontFormat = SimpleDateFormat(getString(R.string.app_front_date))
        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _: DatePicker, year: Int, month: Int, day: Int ->
                calendar.set(year, month, day)
                if (isStart) {
                    addOwnerBirthDateEdit.itemDateEdit.text =
                        frontFormat.format(calendar.time)
                    presenter.physical.birthDate = backFormat.format(calendar.time)
                } else {
                    addOwnerDocumentDateIssue.itemDateEdit.text =
                        frontFormat.format(calendar.time)
                    presenter.physical.documentDateIssue = backFormat.format(calendar.time)
                }
            },
            mYear,
            mMonth,
            mDay
        )
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    private fun setAsteriskMark(): SpannableStringBuilder {
        val colored = "*"
        val builder = SpannableStringBuilder()

        builder.append()
        val start = builder.length
        builder.append(colored)
        val end = builder.length

        builder.setSpan(
            ForegroundColorSpan(Color.RED), start, end,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        return builder
    }

    private fun asterisksFields() {
        val builder = setAsteriskMark()
        asteriskOwnerFirstName.text = builder
        asteriskOwnerLastName.text = builder
        asteriskOwnerINN.text = builder
        asteriskOwnerKatoSpinner.text = builder
        asteriskOwnerBirthDateEdit.text = builder
        asteriskaOwnerDocumentNumber.text = builder
        asteriskaOwnerDocumentDateIssue.text = builder
        asteriskaOwnerDocumentIssueBy.text = builder
        asteriskaOwnerCitizenshipId.text = builder
        asteriskaOwnerMiddleName.text = builder
    }

}