package kz.putinbyte.iszhfermer.entities.animals.owners

data class Owners(
    val birthDate: String = "",
    val citizenshipId: Int? = null,
    val documentDateIssue: String = "",
    val documentNumber: String = "",
    val doumentIssueBy: String = "",
    val email: String = "",
    val firstName: String = "",
    val flat: String = "",
    val house: String = "",
    val id: Int? = null,
    val iin: String? = null,
    val katoId: Int? =null,
    val lastName: String = "",
    val middleName: String = "",
    val mobilePhone: String= "",
    val postIndex: String= "",
    val street: String= "",
    val tel: String= "",
    val fullName : String? = null
)