package kz.putinbyte.iszhfermer.presentation.mainPresenter

import kz.putinbyte.iszhfermer.presentation.base.BaseView

interface MainFragmentView : BaseView {

//    @AddToEndSingle
//    fun setList(list: List<SimpleIszh>)

}