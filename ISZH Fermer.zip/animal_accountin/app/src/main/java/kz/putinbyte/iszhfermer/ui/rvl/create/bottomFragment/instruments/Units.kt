package kz.putinbyte.iszhfermer.ui.rvl.create.bottomFragment.instruments

data class Units(
    var id:Int? = null,
    var nameKz:String,
    var nameRu:String,
    var unitId:Int? = null,
    var textValue:String? = null

)
