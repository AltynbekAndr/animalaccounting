package kz.putinbyte.iszhfermer.entities.requests

data class Role(
    val nameKz: String,
    val nameRu: String,
    val text: String,
    val value: Int
)