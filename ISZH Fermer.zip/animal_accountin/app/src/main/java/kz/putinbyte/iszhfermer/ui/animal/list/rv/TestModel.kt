package kz.putinbyte.iszhfermer.ui.animal.list.rv

data class TestModel(
    val textInj: String?,
    val breed: String?,
    val gender: String?,
    val birthday: String?,
    var isSelected:Boolean = false
)
