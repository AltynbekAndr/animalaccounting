package kz.putinbyte.iszhfermer.entities.animals.individuals

data class OwnersBody(
    var page: Int?,
    var pageSize: Int?,
    var paged: Boolean
)
