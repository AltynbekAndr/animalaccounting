package kz.putinbyte.iszhfermer.entities.animals.fattening

data class Lists(
    val areaActivityId: Int,
    val certificateIssueDate: String,
    val code: String,
    val id: Int,
    val identifier: String,
    val katoId: Int,
    val nameKz: String,
    val nameRu: String,
    val orgStructureId: Int
)