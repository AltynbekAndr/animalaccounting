package kz.putinbyte.iszhfermer.entities.animals

import kz.putinbyte.iszhfermer.entities.BaseFormat

class ModelDisease (
    var position: Int,
    var item: BaseFormat,
    var value: Boolean,
    var textValue:String? = null
)