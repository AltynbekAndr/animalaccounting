package kz.putinbyte.iszhfermer.entities.animals

data class MultiSearchSearch(
    val animalKindId: Int?,
    val inj: String?,
    val ownerId: Int?,
    var katoId:Int?,
    val status:Int?
)

