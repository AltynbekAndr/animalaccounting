package kz.putinbyte.iszhfermer.ui.research.list.rv

data class CauseSicknesses(
    val firstDiagnosis:String?,
    val doctorName:String?,
    val finalDiagnosis:String?,
    val date:String?,
    val conclusion:String?,
    val comment:String?
)
