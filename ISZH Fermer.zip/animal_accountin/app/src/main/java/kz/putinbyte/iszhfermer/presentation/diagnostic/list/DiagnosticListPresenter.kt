package kz.putinbyte.iszhfermer.presentation.diagnostic.list

import kotlinx.coroutines.launch
import kz.putinbyte.iszhfermer.Screens
import kz.putinbyte.iszhfermer.model.interactors.ReferencesInteractor
import kz.putinbyte.iszhfermer.presentation.base.BasePresenter
import ru.terrakok.cicerone.Router
import timber.log.Timber
import javax.inject.Inject

class DiagnosticListPresenter @Inject constructor(
    private val router: Router,
    private val referencesInteractor: ReferencesInteractor
) : BasePresenter<DiagnosticListView>() {

    var animalId:Int? = null

    override fun onFirstViewAttach() {
        super.onFirstViewAttach()

//        initContList()
//        loadContTypes()
//        loadSicknesses()
    }

    private fun loadContTypes() {
        launch {
            try {
                //
//val result = referencesInteractor.getContTypes(false)
               // viewState.showContTypes(result)
            } catch (e: Exception) {
                e.printStackTrace()
                Timber.e(e)
            }
        }
    }



    override fun attachView(view: DiagnosticListView?) {
        super.attachView(view)

     //   viewState.setList(iszhInteractor.getCurrentIszh().wasteStorageTanks!!)
    }


    fun onButtonClicked(animalId:Int?) {
        router.navigateTo(Screens.Diagnostic(animalId))
    }

}