package kz.putinbyte.iszhfermer.entities.animals

data class ScanRegion(
    val number : String?,
    val code: Int?,
    val code2: String?
)