package kz.putinbyte.iszhfermer.ui.research.edit

import android.content.DialogInterface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.CompoundButton
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import kz.putinbyte.iszhfermer.ui.research.edit.rv.ContEditAdapter
import iszhfermer.R
import kotlinx.android.synthetic.main.fragment_cont_edit.*
import kotlinx.android.synthetic.main.item_spinner.view.*
import moxy.presenter.InjectPresenter
import moxy.presenter.ProvidePresenter
import kz.putinbyte.iszhfermer.di.Scopes
import kz.putinbyte.iszhfermer.entities.BaseFormat
import kz.putinbyte.iszhfermer.entities.iszh.Media
import kz.putinbyte.iszhfermer.presentation.research.edit.ContEditPresenter
import kz.putinbyte.iszhfermer.presentation.research.edit.ContEditView
import kz.putinbyte.iszhfermer.presentation.main.MainView
import kz.putinbyte.iszhfermer.ui.base.BaseFragment
import toothpick.Toothpick

class ContEditFragment : BaseFragment(), ContEditView {

    override val layoutResId = R.layout.fragment_cont_edit

    companion object {

        fun newInstance() = ContEditFragment()

        private const val CURRENT_CONT_KEY = "contId"

        fun newInstance(contId: String) = ContEditFragment().apply {
            arguments = Bundle().apply {
                putString(CURRENT_CONT_KEY, contId)
            }
        }
    }

    @InjectPresenter
    lateinit var presenter: ContEditPresenter

    @ProvidePresenter
    fun providePresenter(): ContEditPresenter {
        return Toothpick.openScope(Scopes.DATA_SCOPE)
            .getInstance(ContEditPresenter::class.java)
            .apply {
                contId = arguments?.getString(CURRENT_CONT_KEY) ?: ""
            }
    }

    lateinit var adapter: ContEditAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as MainView).setTitle(getString(R.string.title_container_edit))
        initAdapter()
        initListeners()
    }

    private fun initAdapter() {
        adapter = ContEditAdapter(requireActivity()) { items, position ->
            AlertDialog.Builder(requireActivity())
                .setMessage(getString(R.string.cont_alert_question))
                .setPositiveButton(
                    getString(R.string.cont_alert_yes)
                ) { dialogInterface: DialogInterface, i: Int ->
                    //presenter.onItemClicked(items, position)
                }
                .setNegativeButton(
                    getString(R.string.cont_alert_no),
                    null
                ).show()
        }
        contEditFilesRec.adapter = adapter
        contEditFilesRec.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
    }

    private fun initListeners() {
        contEditSaveButton.setOnClickListener {
            presenter.onSaveClicked()
        }

        contEditNameEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                presenter.setName(s.toString())
            }
        })

        contEditEdit04.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                presenter.setSeparateType(
                    contEditCheck04.text.toString().replace(" (кг)", ""),
                    contEditCheck04.isChecked,
                    s.toString()
                )
            }
        })

        contEditEdit03.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                presenter.setSeparateType(
                    contEditCheck03.text.toString().replace(" (кг)", ""),
                    contEditCheck03.isChecked,
                    s.toString()
                )
            }
        })

        contEditEdit02.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                presenter.setSeparateType(
                    contEditCheck02.text.toString().replace(" (кг)", ""),
                    contEditCheck02.isChecked,
                    s.toString()
                )
            }
        })

        contEditEdit01.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                presenter.setSeparateType(
                    contEditCheck01.text.toString().replace(" (кг)", ""),
                    contEditCheck01.isChecked,
                    s.toString()
                )
            }
        })

        contEditCheck01.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            contEditEdit01.visibility = if (b) View.VISIBLE else View.INVISIBLE
        }

        contEditCheck02.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            contEditEdit02.visibility = if (b) View.VISIBLE else View.INVISIBLE
        }

        contEditCheck03.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            contEditEdit03.visibility = if (b) View.VISIBLE else View.INVISIBLE
        }

        contEditCheck04.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            contEditEdit04.visibility = if (b) View.VISIBLE else View.INVISIBLE
        }

/*        contEditCheck05.setOnCheckedChangeListener { compoundButton: CompoundButton, b: Boolean ->
            contEditEdit05.visibility = if (b) View.VISIBLE else View.INVISIBLE
        }*/

        contEditCommentEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                //presenter.onCommentChanged(s.toString())
            }
        })


        contEditRemoveButton.setOnClickListener {
            presenter.onRemoveClicked()
        }

        contEditTypeSpinner.itemSpinnerSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    presenter.onTypeChanged(contEditTypeSpinner.items, position)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        contEditContTypeSpinner.itemSpinnerSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                  //  presenter.onContTypeChanged(contEditContTypeSpinner.items, position)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        contEditStateSpinner.itemSpinnerSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                   // presenter.onStateChanged(contEditStateSpinner.items, position)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        contEditGarbageSpinner.itemSpinnerSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    presenter.onGarbageChanged(contEditGarbageSpinner.items, position)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
    }


    override fun setList(items: List<Media>) {
        adapter.items = items
    }

    override fun switchTypesVisibility(isVisible: Boolean) {
        contEditCheck01.visibility = if (isVisible) View.VISIBLE else View.GONE
        contEditCheck02.visibility = if (isVisible) View.VISIBLE else View.GONE
        contEditCheck03.visibility = if (isVisible) View.VISIBLE else View.GONE
        contEditCheck04.visibility = if (isVisible) View.VISIBLE else View.GONE
//        contEditCheck05.visibility = if (isVisible) View.VISIBLE else View.GONE

        if (isVisible) {
            contEditEdit01.visibility =
                if (contEditCheck01.isChecked) View.VISIBLE else View.INVISIBLE
            contEditEdit02.visibility =
                if (contEditCheck02.isChecked) View.VISIBLE else View.INVISIBLE
            contEditEdit03.visibility =
                if (contEditCheck03.isChecked) View.VISIBLE else View.INVISIBLE
            contEditEdit04.visibility =
                if (contEditCheck04.isChecked) View.VISIBLE else View.INVISIBLE
//            contEditEdit05.visibility =
//                if (contEditCheck05.isChecked) View.VISIBLE else View.INVISIBLE
        } else {
            contEditEdit01.visibility = View.GONE
            contEditEdit02.visibility = View.GONE
            contEditEdit03.visibility = View.GONE
            contEditEdit04.visibility = View.GONE
//            contEditEdit05.visibility = View.GONE
        }

    }

    override fun switchGarbageVisibility(visible: Boolean) {
        contEditGarbageSpinner.visibility = if (visible) View.VISIBLE else View.GONE
    }

    override fun showContTypes(items: List<BaseFormat>) {
        contEditTypeSpinner.items = items
    }

    override fun showContStates(items: List<BaseFormat>) {
        contEditStateSpinner.items = items
    }


    override fun showTankTypes(items: List<BaseFormat>) {
        contEditContTypeSpinner.items = items
    }

    override fun showGarbageTypes(items: List<BaseFormat>) {
        contEditGarbageSpinner.items = items
        contEditCheck01.setText(items[0].nameRu + " " + getString(R.string.app_tonn))
        contEditCheck02.setText(items[1].nameRu + " " + getString(R.string.app_tonn))
        contEditCheck03.setText(items[2].nameRu + " " + getString(R.string.app_tonn))
        contEditCheck04.setText(items[3].nameRu + " " + getString(R.string.app_tonn))
//        contEditCheck05.setText(items[4].element)
    }
}