package kz.putinbyte.iszhfermer.entities.animals.individuals

data class Errors(
    val BirthDate: List<String>,
    val FirstName: List<String>,
    val LastName: List<String>
)